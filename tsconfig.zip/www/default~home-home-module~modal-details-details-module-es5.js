(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~home-home-module~modal-details-details-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/components/header/header.component.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/header/header.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"tertiary\">\n        <ion-title>Logo</ion-title>\n      <ion-buttons  slot=\"end\">\n        <ion-button>\n          <ion-icon name=\"options\"></ion-icon>\n         </ion-button> \n         <ion-button>\n            <ion-icon name=\"settings\"></ion-icon>\n           </ion-button>\n           <ion-button (click)=\"navigate()\">\n              <ion-icon  name=\"log-out\"></ion-icon>\n             </ion-button>\n     \n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n  \n\n  "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modal/details/details.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modal/details/details.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar  style=\"--background:#4f4d7b;--color:#fff\">\n        <ion-title *ngIf= \"modalType == 'edit'\">Edit Product Details</ion-title>\n        <ion-title *ngIf= \"modalType == 'add'\">Add Product Details</ion-title>\n      </ion-toolbar>\n</ion-header>\n\n<ion-content>\n   <ion-grid no-margin no-padding   *ngIf =\"modalType == 'edit'\">\n  <ion-row>\n    <ion-col >\n      <form [formGroup]=\"editForm\">\n        <ion-list>\n          <ion-item>\n            <ion-input formControlName=\"name\" placeholder=\"name\" [(ngModel)]=\"modalData.name\">\n             </ion-input> \n           </ion-item> \n           <ion-item>\n              <ion-input formControlName=\"category\" placeholder=\"category\" [(ngModel)]=\"modalData.category\">\n               </ion-input> \n             </ion-item> \n             <ion-item> \n                <ion-input formControlName=\"company\" placeholder=\"company\" [(ngModel)]=\"modalData.company\">\n                 </ion-input> \n               </ion-item>    \n             <ion-item>\n                <ion-input formControlName=\"mrp\"  placeholder=\"mrp\" [(ngModel)]=\"modalData.mrp\">\n                 </ion-input> \n               </ion-item> \n               <ion-item>\n                  <ion-input formControlName=\"unit\" placeholder=\"unit\" [(ngModel)]=\"modalData.unit\">\n                   </ion-input> \n                 </ion-item> \n               \n        </ion-list> \n        <div text-right>\n          <ion-button  color=\"tertiary\" (click)=\"update()\">\n            Update\n           </ion-button> \n           <ion-button  color=\"tertiary\" (click)=\"closeModal()\">\n              Cancel\n             </ion-button>\n         </div> \n      </form>  \n     </ion-col> \n   </ion-row> \n </ion-grid>\n\n <ion-grid no-margin no-padding *ngIf =\"modalType == 'add'\">\n    <ion-row>\n      <ion-col >\n        <form [formGroup]=\"editForm\">\n          <ion-list>\n            <ion-item>\n              <ion-input formControlName=\"name\" placeholder=\"name\" [(ngModel)]=\"addForm.name\">\n               </ion-input> \n             </ion-item> \n             <ion-item>\n                <ion-input formControlName=\"category\" placeholder=\"category\" [(ngModel)]=\"addForm.category\">\n                 </ion-input> \n               </ion-item> \n               <ion-item> \n                  <ion-input formControlName=\"company\" placeholder=\"company\" [(ngModel)]=\"addForm.company\">\n                   </ion-input> \n                 </ion-item>    \n               <ion-item>\n                  <ion-input formControlName=\"mrp\"  placeholder=\"mrp\" [(ngModel)]=\"addForm.mrp\">\n                   </ion-input> \n                 </ion-item> \n                 <ion-item>\n                    <ion-input formControlName=\"unit\" placeholder=\"unit\" [(ngModel)]=\"addForm.unit\">\n                     </ion-input> \n                   </ion-item> \n                 \n          </ion-list> \n          <div text-right>\n            <ion-button  color=\"tertiary\" (click)=\"create()\">\n              Create\n             </ion-button> \n             <ion-button  color=\"tertiary\" (click)=\"closeModal()\">\n                Cancel\n               </ion-button>\n           </div> \n        </form>  \n       </ion-col> \n     </ion-row> \n   </ion-grid>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/components/header/header.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(navCntrl) {
        this.navCntrl = navCntrl;
    }
    HeaderComponent.prototype.ngOnInit = function () { };
    HeaderComponent.prototype.navigate = function () {
        this.navCntrl.navigateBack('');
    };
    HeaderComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
    ]; };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.scss */ "./src/app/components/header/header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/components/shared.components.module.ts":
/*!********************************************************!*\
  !*** ./src/app/components/shared.components.module.ts ***!
  \********************************************************/
/*! exports provided: SharedComponentsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedComponentsModule", function() { return SharedComponentsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./header/header.component */ "./src/app/components/header/header.component.ts");






var SharedComponentsModule = /** @class */ (function () {
    function SharedComponentsModule() {
    }
    SharedComponentsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            ],
            declarations: [_header_header_component__WEBPACK_IMPORTED_MODULE_5__["HeaderComponent"]],
            exports: [_header_header_component__WEBPACK_IMPORTED_MODULE_5__["HeaderComponent"]]
        })
    ], SharedComponentsModule);
    return SharedComponentsModule;
}());



/***/ }),

/***/ "./src/app/modal/details/details.page.scss":
/*!*************************************************!*\
  !*** ./src/app/modal/details/details.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".background {\n  background: #1f0b79;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kYWwvZGV0YWlscy9DOlxcVXNlcnNcXEFzaHdpbmlfREZcXERlc2t0b3BcXGlvbmljX3Byb2plY3RfbWluZVxcbXlGaXJzdC9zcmNcXGFwcFxcbW9kYWxcXGRldGFpbHNcXGRldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9tb2RhbC9kZXRhaWxzL2RldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL21vZGFsL2RldGFpbHMvZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmFja2dyb3VuZHtcclxuICAgIGJhY2tncm91bmQ6cmdiKDMxLCAxMSwgMTIxKVxyXG59IiwiLmJhY2tncm91bmQge1xuICBiYWNrZ3JvdW5kOiAjMWYwYjc5O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/modal/details/details.page.ts":
/*!***********************************************!*\
  !*** ./src/app/modal/details/details.page.ts ***!
  \***********************************************/
/*! exports provided: DetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPage", function() { return DetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _services_products_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/products.service */ "./src/app/services/products.service.ts");





var DetailsPage = /** @class */ (function () {
    function DetailsPage(navParam, modal, toast, serve) {
        this.navParam = navParam;
        this.modal = modal;
        this.toast = toast;
        this.serve = serve;
        this.addForm = {
            name: '',
            category: '',
            company: '',
            unit: '',
            mrp: '',
        };
        this.modalData = this.navParam.get('product_id');
        this.modalType = this.navParam.get('type');
        console.log(this.modalType);
        console.log('getting modal data', this.modalData);
    }
    DetailsPage.prototype.ngOnInit = function () {
        this.editForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroup"]({
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
            category: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
            mrp: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
            unit: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
            company: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
        });
    };
    DetailsPage.prototype.closeModal = function () {
        this.modal.dismiss();
    };
    DetailsPage.prototype.update = function () {
        console.log("editForm", this.editForm.value);
        this.tosterCreate('updated Successfully');
    };
    DetailsPage.prototype.tosterCreate = function (data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var Toasts;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toast.create({
                            message: data,
                            duration: 2000,
                            color: "success",
                        })];
                    case 1:
                        Toasts = _a.sent();
                        return [4 /*yield*/, Toasts.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    DetailsPage.prototype.create = function () {
        console.log(this.editForm.value);
        var val = this.editForm.value;
        this.serve.moreProducts(val);
        this.tosterCreate('Created Successfully');
        this.closeModal();
    };
    DetailsPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
        { type: _services_products_service__WEBPACK_IMPORTED_MODULE_4__["ProductsService"] }
    ]; };
    DetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-details',
            template: __webpack_require__(/*! raw-loader!./details.page.html */ "./node_modules/raw-loader/index.js!./src/app/modal/details/details.page.html"),
            styles: [__webpack_require__(/*! ./details.page.scss */ "./src/app/modal/details/details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"], _services_products_service__WEBPACK_IMPORTED_MODULE_4__["ProductsService"]])
    ], DetailsPage);
    return DetailsPage;
}());



/***/ }),

/***/ "./src/app/services/products.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/products.service.ts ***!
  \**********************************************/
/*! exports provided: ProductsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsService", function() { return ProductsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var url = 'http://134.209.147.129:3001';
var ProductsService = /** @class */ (function () {
    function ProductsService(http) {
        this.http = http;
        this.products = [
            {
                id: 1,
                name: 'fertmax124',
                mrp: '12',
                unit: 'kg',
                category: 'prods567',
                company: 'zilla',
            },
            {
                id: 2,
                name: 'agriCopla',
                mrp: '12',
                unit: 'kg',
                category: 'prodsr34',
                company: 'zilla',
            },
            {
                id: 3,
                name: 'SeedMary',
                mrp: '12',
                unit: 'kg',
                category: 'prods12',
                company: 'zilla',
            },
            {
                id: 4,
                name: 'SeedsGrow',
                mrp: '12',
                unit: 'kg',
                category: 'prods1',
                company: 'zilla',
            }
        ];
    }
    ProductsService.prototype.allProducts = function () {
        return this.products;
    };
    ProductsService.prototype.getIdProducts = function (id) {
        console.log('id', id);
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.products.find(function (ele) {
            return ele.id == id;
        }));
    };
    ProductsService.prototype.deleteProd = function (id) {
        var _this = this;
        this.products.forEach(function (ele, index) {
            if (ele.id == id) {
                _this.products.splice(index, 1);
            }
        });
    };
    ProductsService.prototype.moreProducts = function (val) {
        if (val.id == null) {
            var maxId = this.products.reduce(function (e1, e2) {
                return (e1 > e2 ? e1 : e2);
            }).id;
            val.id = maxId + 1;
            this.products.push(val);
        }
    };
    ProductsService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"] }
    ]; };
    ProductsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"]])
    ], ProductsService);
    return ProductsService;
}());



/***/ })

}]);
//# sourceMappingURL=default~home-home-module~modal-details-details-module-es5.js.map